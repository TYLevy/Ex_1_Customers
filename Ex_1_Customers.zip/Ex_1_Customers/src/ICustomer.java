public interface ICustomer {
    String getCustomerName();
    double getPriceForProduct(double fullPrice);
}
